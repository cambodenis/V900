package com.example.sbi.utils

enum class DisplayOrientation{
    Landscape, Portrait,
}
enum class DisplaySize{
    Compact, Medium, Large
}