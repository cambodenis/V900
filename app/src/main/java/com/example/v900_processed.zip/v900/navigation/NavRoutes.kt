package com.example.v900.navigation

object NavRoutes {
    const val RUN = "run"
    const val BILGE = "bilge"
    const val HOME = "home"
    const val SERVICES = "services"
    const val LIGHTS = "lights"
    const val SETTINGS = "settings"
}